#ifndef __ILI9341_LIB_H__
#define __ILI9341_LIB_H__

#include "main.h"

/*-----------------------------------------------------------------------------
 * Definições de Orientação e Resolução do LCD
 *-----------------------------------------------------------------------------
 * O LCD pode ser configurado para orientação vertical ou horizontal. A
 * resolução (X_RES e Y_RES) é definida com base na orientação.
 */
#define VERTICAL    0
#define HORIZONTAL  1

/// Define a orientação do display: VERTICAL ou HORIZONTAL.
#define LCD_ALIGNMENT HORIZONTAL

#if LCD_ALIGNMENT == VERTICAL
    #define X_RES 240
    #define Y_RES 320
#else
    #define X_RES 320
    #define Y_RES 240
#endif

/*-----------------------------------------------------------------------------
 * Extern: SPI Handle
 *-----------------------------------------------------------------------------
 * O objeto hspi1 deve ser definido na sua aplicação (ex.: main.c) e
 * representa a interface SPI utilizada para comunicação com o LCD.
 */
extern SPI_HandleTypeDef hspi1;

/*-----------------------------------------------------------------------------
 * Outros Extern
 *----------------------------------------------------------------------------- */

extern unsigned short palette[];

/*-----------------------------------------------------------------------------
 * Funções de Comunicação com o LCD
 *-----------------------------------------------------------------------------
 */

/**
 * @brief Envia um comando (1 byte) para o LCD.
 * @param comm Comando a ser enviado.
 */
void LCD_WriteComm(unsigned char comm);

/**
 * @brief Envia um dado (1 byte) para o LCD.
 * @param data Dado a ser enviado.
 */
void LCD_WriteData(unsigned char data);

/**
 * @brief Envia um dado de 16 bits para o LCD (convertendo para big-endian).
 * @param data Dado de 16 bits a ser enviado.
 */
void LCD_WriteData2(unsigned short data);

/**
 * @brief Envia N bytes de dados para o LCD.
 * @param b Ponteiro para o buffer de dados.
 * @param n Número de bytes a transmitir.
 */
void LCD_WriteDataN(unsigned char *b, int n);

/**
 * @brief Inicializa o LCD com a sequência de comandos necessária.
 */
void LCD_Init(void);

/**
 * @brief Define o cursor do LCD (janela de 1 pixel) em uma posição específica.
 * @param x Coordenada horizontal.
 * @param y Coordenada vertical.
 */
void LCD_SetCursor(unsigned short x, unsigned short y);

/**
 * @brief Limpa a tela do LCD preenchendo-a com a cor especificada.
 * @param color Cor de preenchimento (formato RGB565).
 */
void LCD_Clear(unsigned short color);

/*-----------------------------------------------------------------------------
 * Funções de Desenho Básico
 *-----------------------------------------------------------------------------
 */

/**
 * @brief Desenha um pixel na posição (x, y) com a cor especificada.
 * @param x Coordenada horizontal.
 * @param y Coordenada vertical.
 * @param color Cor do pixel (formato RGB565).
 */
void drawPixel(unsigned short x, unsigned short y, unsigned short color);

/**
 * @brief Retorna a cor do pixel na posição (x, y).
 * @param x Coordenada horizontal.
 * @param y Coordenada vertical.
 * @return Cor do pixel (formato RGB565).
 */
unsigned short getColor(unsigned short x, unsigned short y);

/*-----------------------------------------------------------------------------
 * Funções para Paleta de Cores e Manipulação de Pixels
 *-----------------------------------------------------------------------------
 */

/**
 * @brief Configura uma entrada na paleta de cores, convertendo valores RGB
 *        de 8 bits para o formato RGB565.
 * @param n Índice da paleta.
 * @param b Componente azul (0-255).
 * @param r Componente vermelho (0-255).
 * @param g Componente verde (0-255).
 */
void set_palette(unsigned char n, unsigned char b, unsigned char r, unsigned char g);

/**
 * @brief Plota um pixel utilizando o índice da paleta, com verificação de limites.
 * @param x Coordenada horizontal.
 * @param y Coordenada vertical.
 * @param c Índice de cor na paleta.
 */
void pset(int x, int y, unsigned char c);

/**
 * @brief Desenha um bitmap com dimensões m x n no ponto (x, y). Pixels com valor 0
 *        são tratados como transparentes.
 * @param x Coordenada horizontal de início.
 * @param y Coordenada vertical de início.
 * @param m Largura do bitmap.
 * @param n Altura do bitmap.
 * @param bmp Ponteiro para os dados do bitmap.
 */
void putbmpmn(int x, int y, unsigned char m, unsigned char n, const unsigned char bmp[]);

/**
 * @brief Limpa a área onde um bitmap foi desenhado, preenchendo com a cor de fundo.
 * @param x Coordenada horizontal de início.
 * @param y Coordenada vertical de início.
 * @param m Largura da área.
 * @param n Altura da área.
 */
void clrbmpmn(int x, int y, unsigned char m, unsigned char n);

/*-----------------------------------------------------------------------------
 * Funções de Desenho de Linhas e Formas
 *-----------------------------------------------------------------------------
 */

/**
 * @brief Desenha uma linha entre os pontos (x1, y1) e (x2, y2) utilizando o
 *        algoritmo de Bresenham.
 * @param x1 Coordenada horizontal do ponto inicial.
 * @param y1 Coordenada vertical do ponto inicial.
 * @param x2 Coordenada horizontal do ponto final.
 * @param y2 Coordenada vertical do ponto final.
 * @param c Índice de cor na paleta.
 */
void gline(int x1, int y1, int x2, int y2, unsigned char c);

/**
 * @brief Desenha uma linha horizontal entre x1 e x2 na posição y.
 * @param x1 Coordenada horizontal de início.
 * @param x2 Coordenada horizontal de fim.
 * @param y Coordenada vertical.
 * @param c Índice de cor na paleta.
 */
void hline(int x1, int x2, int y, unsigned char c);

/**
 * @brief Desenha o contorno de um círculo utilizando o algoritmo do ponto médio.
 * @param x0 Coordenada horizontal do centro.
 * @param y0 Coordenada vertical do centro.
 * @param r Raio do círculo.
 * @param c Índice de cor na paleta.
 */
void circle(int x0, int y0, unsigned int r, unsigned char c);

/**
 * @brief Desenha um retângulo preenchido (box) entre os pontos (x1, y1) e (x2, y2).
 * @param x1 Primeira coordenada horizontal.
 * @param y1 Primeira coordenada vertical.
 * @param x2 Segunda coordenada horizontal.
 * @param y2 Segunda coordenada vertical.
 * @param c Índice de cor na paleta.
 */
void boxfill(int x1, int y1, int x2, int y2, unsigned char c);

/**
 * @brief Desenha um círculo preenchido, utilizando linhas horizontais.
 * @param x0 Coordenada horizontal do centro.
 * @param y0 Coordenada vertical do centro.
 * @param r Raio do círculo.
 * @param c Índice de cor na paleta.
 */
void circlefill(int x0, int y0, unsigned int r, unsigned char c);

/*-----------------------------------------------------------------------------
 * Funções de Desenho de Texto
 *-----------------------------------------------------------------------------
 */

/**
 * @brief Imprime uma string na posição (x, y) utilizando os dados da fonte.
 * @param x Coordenada horizontal.
 * @param y Coordenada vertical.
 * @param c Índice de cor do texto.
 * @param bc Índice de cor do background (-1 para transparente).
 * @param s Ponteiro para a string (terminada em NULO) a ser impressa.
 */
void printstr(int x, int y, unsigned char c, int bc, unsigned char *s);

/**
 * @brief Imprime um número sem zeros à esquerda na posição (x, y).
 * @param x Coordenada horizontal.
 * @param y Coordenada vertical.
 * @param c Índice de cor do texto.
 * @param bc Índice de cor do background.
 * @param n Número a ser impresso.
 */
void printnum(int x, int y, unsigned char c, int bc, unsigned int n);

/**
 * @brief Imprime um número com um número fixo de dígitos na posição (x, y),
 *        preenchendo com espaços se necessário.
 * @param x Coordenada horizontal.
 * @param y Coordenada vertical.
 * @param c Índice de cor do texto.
 * @param bc Índice de cor do background.
 * @param n Número a ser impresso.
 * @param e Número de dígitos a serem exibidos.
 */
void printnum2(int x, int y, unsigned char c, int bc, unsigned int n, unsigned char e);

/*-----------------------------------------------------------------------------
 * Função de Inicialização Geral dos Gráficos
 *-----------------------------------------------------------------------------
 */

/**
 * @brief Inicializa o sistema gráfico: configura a paleta de cores, inicializa o LCD
 *        e limpa a tela.
 */
void init_graphic(void);

/*-----------------------------------------------------------------------------
 * Variáveis Externas
 *-----------------------------------------------------------------------------
 */

/**
 * @brief Array de paleta de cores, onde cada entrada é um valor RGB565.
 */

#endif
